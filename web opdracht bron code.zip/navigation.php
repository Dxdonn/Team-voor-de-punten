<nav class="navbar navbar-expand-sm bg-primary mb-5" id="global-navbar">
  <div class=" container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?= $prefix ?>index.php">thuis</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= $prefix ?>contact.php">contactinformatie</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= $prefix ?>video-pagina.php">
          <i class="fa-solid fa-video"></i>
          video pagina
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= $prefix ?>demo-page-2.php">demo pagina</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= $prefix ?>bootstrap.php">bootstrap demo</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= $prefix ?>responsive.php">breakpoints demo</a>
      </li>
    </ul>
  </div>
</nav>