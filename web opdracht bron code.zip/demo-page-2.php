<!DOCTYPE html>
<html lang="nl">

<head>
  <title>Demo pagina</title>
  <?php require 'head.php'; ?>
</head>

<body>
  <?php require 'navigation.php'; ?>
</body>

</html>