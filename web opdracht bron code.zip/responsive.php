<!DOCTYPE html>
<html lang="nl">

<head>
  <title>Bootstrap Demo Page</title>
  <?php require 'head.php'; ?>
  <link rel="stylesheet" href="responsive.css">
</head>

<body>
  <?php require 'navigation.php'; ?>
  <main id="content">
  </main>
</body>

</html>