<!DOCTYPE html>
<html lang="nl">

<head>
  <title>Een video</title>
  <?php require 'head.php'; ?>
</head>

<body>
  <?php require 'navigation.php'; ?>
  <main id="content">
    <h1>Video-pagina</h1>
    <video class="adventuretime" controls autoplay muted>
      <source src="Rick%20Astley%20-%20NGGYU.mp4" type="video/mp4">\
      Browser requires javascript to autoplay without mute.
    </video>
  </main>
</body>

</html>